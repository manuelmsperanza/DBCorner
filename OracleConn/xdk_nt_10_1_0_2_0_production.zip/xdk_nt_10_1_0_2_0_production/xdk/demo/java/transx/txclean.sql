
-- txdemo1.sql

DROP TABLE i18n_messages;
DROP SEQUENCE i18n_message_seq;
DROP TABLE i18n_message_types;

commit;
