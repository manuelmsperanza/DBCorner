@@insclaim/insclaim.sql
@@document/docdemo.sql
@@classerr/invalidclasses.sql
@@airport/airport.sql
@@insertxml/newsstory.sql
@@empdept/empdeptobjs.sql

