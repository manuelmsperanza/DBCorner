connect scott/tiger

drop table xmltest_tab1;
create table xmltest_tab1 (EMPNO NUMBER(4), ENAME CHAR(10), JOB VARCHAR2(9));
